import os
import shutil
from threading import Thread
import webbrowser

def run_flask_app():
    """Importuje a spustí Flask aplikaci."""
    from app import app
    # Spustíme Flask v samostatném vlákně, aby neblokoval hlavní vlákno
    # a zároveň otevřeme prohlížeč.
    url = "http://127.0.0.1:5000"
    
    def start_server():
        app.run(debug=False, use_reloader=False)

    # Spuštění serveru v samostatném vlákně
    server_thread = Thread(target=start_server)
    server_thread.daemon = True
    server_thread.start()
    
    # Otevření prohlížeče
    try:
        webbrowser.open(url)
        print(f"Webové rozhraní by se mělo otevřít v prohlížeči na adrese: {url}")
    except Exception as e:
        print(f"Nepodařilo se automaticky otevřít prohlížeč. Otevřete prosím manuálně: {url}")
        print(f"Chyba: {e}")

    server_thread.join() # Čekáme na ukončení serveru (např. Ctrl+C v terminálu)


def run_cli_app():
    """Importuje a spustí CLI rozhraní."""
    from extract_bill_json import run_cli
    run_cli()

if __name__ == "__main__":
    # --- Automatický úklid při spuštění ---
    # Cesta k adresáři pro dočasně nahrané soubory
    UPLOADS_DIR = "uploads"
    
    # Pokud adresář 'uploads' existuje z předchozího běhu, smažeme ho
    if os.path.exists(UPLOADS_DIR):
        print(f"Provádím úklid: Mažu dočasný adresář '{UPLOADS_DIR}'...")
        try:
            shutil.rmtree(UPLOADS_DIR)
            print("Úklid dokončen.")
        except OSError as e:
            print(f"Chyba při mazání adresáře {UPLOADS_DIR}: {e}")

    while True:
        print("\nCo si přejete spustit?")
        print("1: Grafické rozhraní v prohlížeči (GUI)")
        print("2: Rozhraní v příkazovém řádku (CLI)")
        print("0: Ukončit")
        
        volba = input("Zadejte svou volbu (1, 2 nebo 0): ").strip()
        
        if volba == '1':
            print("Spouštím grafické rozhraní...")
            run_flask_app()
            break
        elif volba == '2':
            print("Spouštím rozhraní v příkazovém řádku...")
            run_cli_app()
            break
        elif volba == '0':
            print("Ukončuji program.")
            break
        else:
            print("Neplatná volba, zkuste to znovu.")
